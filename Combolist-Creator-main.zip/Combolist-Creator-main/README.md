# Combolist Creator 🪐
This tool is capable of obtaining between 1 million and more than 150 million fresh accounts for you to verify on any platform!

## 🔥 Features
- Fully Requests Based Creator
- Accounts Saved (email:pass)
- Auto Capture / Duplicated Remover
- Proxyless
- Over 1M - 150 Million Accounts
- Fresh Combolists
- Gaming, Shopping, Streaming and more...

## ✍️ Usage
1. Open `config.json` and set your settings.
2. Open `main.py`

## ⚠️ DISCLAIMER / NOTES
This github repo is for EDUCATIONAL PURPOSES ONLY. We are NOT under any responsibility if a problem occurs.

## ✨ Issues / Doubts

- If you have any questions do not hesitate to enter my discord: https://discord.gg/raducord
- Or if you have any error do not forget to report it in: [issues](https://github.com/H4cK3dR4Du/Combolist-Creator/issues/new)
